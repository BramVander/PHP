<?php
    $hn = 'localhost';
    $db = 'lidmaatschap';
    $un = 'vander';
    $pw = 'mysql';
?>