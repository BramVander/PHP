<?php
    $hn = 'localhost';
    $db = 'vereniging';
    $un = 'vander';
    $pw = 'mysql';
?>